package com.ashish.search;

import java.util.ArrayList;

import com.hb.search.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class SearchBarInListVIewActivity extends Activity {

	private EditText editText;
	@SuppressWarnings("unused")
	private MyAdapter myAdapter;
	private ArrayList<String> mydata = new ArrayList<String>();
	private ArrayList<String> mydata2 = new ArrayList<String>();
	private ListView listView;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		listView = (ListView) findViewById(R.id.listView1);
		listView.setTextFilterEnabled(true);
		
		mydata.add("asdamklisd");
		mydata.add("Asdaqazsd");
		mydata.add("bsdasbnmbvnd");
		mydata.add("gasdasd");
		mydata.add("wasdasd");
		mydata.add("Bfsdaqwesd");
		mydata.add("hadsfsdaertsd");
		mydata.add("oasdatrysd");

		mydata.add("basdamklisd");
		mydata.add("cAsdaqazsd");
		mydata.add("dbsdasbnmbvnd");
		mydata.add("egasdasd");
		mydata.add("fwasdasd");
		mydata.add("gBfsdaqwesd");
		mydata.add("hadsfsdaertsd");
		mydata.add("ioasdatrysd");
		
		mydata.add("jasdamklisd");
		mydata.add("kAsdaqazsd");
		mydata.add("lbsdasbnmbvnd");
		mydata.add("mgasdasd");
		mydata.add("nwasdasd");
		mydata.add("oBfsdaqwesd");
		mydata.add("phadsfsdaertsd");
		mydata.add("qoasdatrysd");
		
		mydata.add("rkAsdaqazsd");
		mydata.add("slbsdasbnmbvnd");
		mydata.add("tmgasdasd");
		mydata.add("unwasdasd");
		mydata.add("voBfsdaqwesd");
		mydata.add("wphadsfsdaertsd");
		mydata.add("xqoasdatrysd");
		
		
		mydata.add("xkAsdaqazsd");
		mydata.add("ylbsdasbnmbvnd");
		mydata.add("zmgasdasd");
		mydata.add("1nwasdasd");
		mydata.add("2oBfsdaqwesd");
		mydata.add("3phadsfsdaertsd");
		mydata.add("qoasdatrysd");
		
		editText = (EditText) findViewById(R.id.et_key);
		
	    for (int i = 0; i < mydata.size(); i++) 
	    {
			mydata2.add("KK"+i);
		}
	    
		
	    searchUsingArrayAdapter();
	    
		
		Button btn_Search = (Button) findViewById(R.id.btn_search);
	    btn_Search.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0)
			{
				String s = editText.getText().toString();
			}
		});
	
	
	}

	
	
	@SuppressWarnings({ "unused", "unchecked", "rawtypes" })
	private void searchUsingArrayAdapter() 
	{
//		 ArrayAdapter<?> arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,mydata);
//		 listView.setAdapter(arrayAdapter);
//		 MyTextWatcherUsingArrayAdapter myTextWatcher = new MyTextWatcherUsingArrayAdapter(SearchBarInListVIewActivity.this, listView,arrayAdapter);
//		 editText.addTextChangedListener(myTextWatcher);
		 
		 	
			myAdapter = new MyAdapter(SearchBarInListVIewActivity.this,mydata);
			listView.setAdapter(myAdapter);
			MyTextWatcher myTextWatcher = new MyTextWatcher(editText, listView, SearchBarInListVIewActivity.this, mydata);
		    editText.addTextChangedListener(myTextWatcher);
	}
	
}