package com.ashish.search;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.app.Activity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;

public class MyTextWatcher implements TextWatcher 
{
    private int textlength = 0;
	private EditText editText;
    private ListView listView;
    private Activity activity;
    private ArrayList<String> serachList = new ArrayList<String>();
    private ArrayList<String> serachListCopy;
    
    public MyTextWatcher(EditText et,ListView listview,Activity a,ArrayList<String> searchArrayList)
    {
    	editText = et;
    	listView = listview;
    	activity = a;
    	serachList = searchArrayList;
    	serachListCopy = new ArrayList<String>(serachList);
    }
    
    
    
	@Override
	public void afterTextChanged(Editable s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) 
	{
		
		textlength=editText.getText().length();
		
		if(textlength==0)
		{
			listView.setAdapter(new MyAdapter(activity,serachListCopy));				
		}
		else
		{
			int len = serachListCopy.size();
			
			serachList.clear();
			
			
			String keyToSearch = editText.getText().toString();
			
			for(int i=0;i<len;i++)
			{
			  if(textlength<=serachListCopy.get(i).length())
			   {
				  
				  // only at start of the string 
			      if(editText.getText().toString().equalsIgnoreCase((String) serachListCopy.get(i).subSequence(0, textlength)))
				
				 // contains character 
				 //if(serachListCopy.get(i).toString().contains(editText.getText().toString()))
				  {
					 serachList.add(serachListCopy.get(i));
			      }
			   }
		    }
			
			/*
			Collections.binarySearch(serachListCopy,keyToSearch,new Comparator<String>() 
			{
				@Override
				public int compare(String lhs, String rhs) 
				{
					return 0;
				}
			});
			*/
		  
			listView.setAdapter(new MyAdapter(activity,serachList));	
		}
		
	}

}
