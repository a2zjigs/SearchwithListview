package com.ashish.search;

import java.util.ArrayList;

import com.hb.search.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MyAdapter  extends BaseAdapter
{
	private ArrayList<String> mydata = new ArrayList<String>();
    private Context context;
	
	public MyAdapter(Context searchBarInListVIewActivity,
			ArrayList<String> data) {
        mydata = data;
        context = searchBarInListVIewActivity;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mydata.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return mydata.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	public static class MyHolder
	{
		TextView textView;
	}
	
	
	@Override
	public View getView(int position, View convertView, ViewGroup arg2) 
	{
		MyHolder myHolder = null;
		
		if(convertView==null)
		{
			LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = layoutInflater.inflate(R.layout.adapterview, null);
			
			myHolder = new MyHolder();
		    convertView.setTag(myHolder);
		}
		else
		{
			myHolder = (MyHolder) convertView.getTag();
		}
		
		myHolder.textView = (TextView) convertView.findViewById(R.id.textview);
        myHolder.textView.setText(mydata.get(position));
		
		return convertView;
	}
}
