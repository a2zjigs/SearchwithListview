package com.ashish.search;

import android.app.Activity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MyTextWatcherUsingArrayAdapter implements TextWatcher
{
    @SuppressWarnings("unused")
	private ListView listView;
    @SuppressWarnings("unused")
	private Activity activity;
    private ArrayAdapter<?> arrayAdapter;
	public MyTextWatcherUsingArrayAdapter(Activity a,ListView listview,ArrayAdapter<?> arrayAdapterOfThisListView)
    {
    	try
    	{
    	 listView = listview;
    	 activity = a;
         listview.setTextFilterEnabled(true);
         arrayAdapter = arrayAdapterOfThisListView;
        }
    	catch (Exception e) 
    	{
    		e.printStackTrace();
    	}
    }

	@Override
	public void afterTextChanged(Editable s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		arrayAdapter.getFilter().filter(s);
	}
}
